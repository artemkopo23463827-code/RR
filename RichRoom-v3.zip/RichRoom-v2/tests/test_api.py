import os,tempfile,unittest
folder=tempfile.TemporaryDirectory(); os.environ['DB_PATH']=folder.name+'/test.sqlite3';os.environ['ALLOW_BROWSER_DEMO']='1'
from backend.server import app
class API(unittest.TestCase):
 def test_flow(self):
  c=app.test_client(); h={'X-Demo-Session':c.post('/api/session').json['session']}; self.assertEqual(c.get('/api/state',headers=h).json['balance'],2500)
  s=c.post('/api/open',json={'id':0},headers=h).json;self.assertEqual(s['balance'],2450); p=s['result']; s=c.post('/api/item',json={'id':p['id'],'action':'sell'},headers=h).json;self.assertEqual(s['balance'],2450+p['value']);self.assertEqual(c.post('/api/item',json={'id':p['id'],'action':'sell'},headers=h).status_code,400)
  self.assertEqual(c.post('/api/topup',json={},headers=h).json['balance'],3450+p['value'])
if __name__=='__main__':unittest.main()

import os, json, sqlite3, secrets, hashlib, hmac, time, random
from pathlib import Path
from urllib.parse import parse_qsl
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv
from backend.catalog import CASES
ROOT=Path(__file__).resolve().parents[1]; load_dotenv(ROOT/'.env')
app=Flask(__name__,static_folder=str(ROOT/'frontend'),static_url_path='/static')
DB=os.getenv('DB_PATH',str(ROOT/'demo.sqlite3')); TOKEN=os.getenv('BOT_TOKEN',''); DEMO=os.getenv('ALLOW_BROWSER_DEMO','1')=='1'
def connect():
 c=sqlite3.connect(DB,timeout=15); c.row_factory=sqlite3.Row; return c
with connect() as c:
 c.executescript('CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,balance INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,user TEXT,case_name TEXT,prize TEXT,status TEXT,created INTEGER);')
def identity():
 raw=request.headers.get('X-Telegram-Init-Data','')
 if raw:
  if not TOKEN: raise ValueError('Бот не настроен')
  d=dict(parse_qsl(raw,keep_blank_values=True)); supplied=d.pop('hash',''); key=hmac.new(b'WebAppData',TOKEN.encode(),hashlib.sha256).digest(); check='\n'.join(f'{k}={v}' for k,v in sorted(d.items()))
  if not hmac.compare_digest(supplied,hmac.new(key,check.encode(),hashlib.sha256).hexdigest()) or abs(time.time()-int(d['auth_date']))>86400: raise ValueError('Недействительная авторизация')
  return 'tg:'+str(json.loads(d['user'])['id'])
 if not DEMO: raise ValueError('Откройте приложение в Telegram')
 sid=request.headers.get('X-Demo-Session','');
 if len(sid)!=64 or any(x not in '0123456789abcdef' for x in sid): raise ValueError('Нет демо-сессии')
 return 'demo:'+sid
@app.errorhandler(ValueError)
@app.errorhandler(KeyError)
def bad(e): return jsonify(error=str(e)),400
@app.get('/')
def index(): return send_from_directory(ROOT/'frontend','index.html')
@app.get('/api/catalog')
def catalog(): return jsonify(CASES)
@app.post('/api/session')
def session():
 if not DEMO: return jsonify(error='Демо отключено'),403
 return jsonify(session=secrets.token_hex(32))
@app.route('/api/state',methods=['GET'])
@app.post('/api/topup')
@app.post('/api/open')
@app.post('/api/item')
def action():
 uid=identity(); data=request.get_json(silent=True) or {}; result=None
 # Одна транзакция блокирует параллельные списания и повторную продажу.
 with connect() as c:
  c.execute('BEGIN IMMEDIATE'); c.execute('INSERT OR IGNORE INTO users VALUES (?,2500)',(uid,)); balance=c.execute('SELECT balance FROM users WHERE id=?',(uid,)).fetchone()[0]
  if request.path.endswith('/topup'): balance+=1000
  elif request.path.endswith('/open'):
   case=next((x for x in CASES if x['id']==data.get('id')),None)
   if not case: raise ValueError('Кейс не найден')
   if balance<case['price']: raise ValueError('Недостаточно звёзд')
   balance-=case['price']; prize=random.SystemRandom().choices(case['prizes'],weights=[p['weight'] for p in case['prizes']])[0]
   cur=c.execute('INSERT INTO items(user,case_name,prize,status,created) VALUES(?,?,?,?,?)',(uid,case['name'],json.dumps(prize,ensure_ascii=False),'available',int(time.time()))); result=dict(id=cur.lastrowid,**prize)
  elif request.path.endswith('/item'):
   item=c.execute('SELECT * FROM items WHERE id=? AND user=?',(data.get('id'),uid)).fetchone(); op=data.get('action')
   if not item or item['status']!='available' or op not in ('sell','claim'): raise ValueError('Действие недоступно')
   if op=='sell': balance+=json.loads(item['prize'])['value']
   c.execute('UPDATE items SET status=? WHERE id=?',('sold' if op=='sell' else 'claimed',item['id']))
  c.execute('UPDATE users SET balance=? WHERE id=?',(balance,uid)); items=[dict(id=r['id'],case_name=r['case_name'],status=r['status'],created=r['created'],**json.loads(r['prize'])) for r in c.execute('SELECT * FROM items WHERE user=? ORDER BY id DESC',(uid,))]
 return jsonify(balance=balance,items=items,result=result)
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','8000')))

# Long polling: запускайте только один экземпляр бота.
import os,time,requests
from dotenv import load_dotenv
load_dotenv(); token=os.environ['BOT_TOKEN']; url=os.environ['MINI_APP_URL']; base=f'https://api.telegram.org/bot{token}/'
assert url.startswith('https://'), 'Нужен HTTPS URL'
def call(method,**data):
 r=requests.post(base+method,json=data,timeout=40); r.raise_for_status(); return r.json()['result']
offset=0
while True:
 try:
  for u in call('getUpdates',offset=offset,timeout=25,allowed_updates=['message']):
   m=u.get('message',{}); text=m.get('text','');
   if text.split(' ')[0].split('@')[0]=='/start' and m['chat']['type']=='private': call('sendMessage',chat_id=m['chat']['id'],text='Rich Room — коллекция виртуальных подарков. Только демо.',reply_markup={'inline_keyboard':[[{'text':'Открыть Rich Room','web_app':{'url':url}}]]})
   offset=u['update_id']+1
 except requests.RequestException as e:
  print('Ошибка соединения с Telegram:',type(e).__name__); time.sleep(5)

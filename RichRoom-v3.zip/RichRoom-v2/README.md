# Rich Room — локальное демо TMA
Только виртуальные предметы и тестовые звёзды. Нет платежей, вывода, реальных Telegram Gifts. Python 3.10+.

## Запуск (Windows PowerShell)
```powershell
cd rich-room
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
.\.venv\Scripts\python.exe -m backend.server
```
Откройте http://localhost:8000. Начальный баланс 2500; плюс начисляет 1000. На macOS/Linux используйте `python3 -m venv .venv`, `.venv/bin/python -m pip install -r requirements.txt`, `cp .env.example .env`, `.venv/bin/python -m backend.server`.

## Telegram
1. Создайте бота через @BotFather командой /newbot. Сохраните токен только в локальном `.env` (не отправляйте его в чат и не коммитьте).
2. Установите cloudflared и в отдельном терминале выполните `cloudflared tunnel --url http://localhost:8000` (или `ngrok http 8000` после настройки аккаунта ngrok).
3. Скопируйте выданный HTTPS URL в `MINI_APP_URL`, токен в `BOT_TOKEN`. Для доступа только через Telegram установите `ALLOW_BROWSER_DEMO=0`.
4. Перезапустите сервер после изменения .env. В отдельном терминале из корня запустите `.\.venv\Scripts\python.exe -m bot.main` (Linux/macOS: `.venv/bin/python -m bot.main`). Если ранее использовали webhook, удалите его через Bot API deleteWebhook перед polling.
5. Откройте своего бота в Telegram, отправьте /start и нажмите кнопку Rich Room. При желании настройте кнопку меню через BotFather /setmenubutton с тем же HTTPS URL. При смене URL обновите .env и перезапустите бота.

## Файлы
- backend/catalog.py: категории, 28 кейсов, цены, веса, стоимость продажи. Вес нормализуется относительно суммы весов; редактируйте список prizes для индивидуальных наборов.
- backend/server.py: Flask, SQLite, проверка подписи Telegram initData, транзакции, серверный выбор призов, API.
- frontend/index.html: оболочка, Telegram SDK; style.css: красно-чёрная тема, адаптивность, анимация; app.js: каталог, поиск, сортировка, модальные окна, рулетка, инвентарь, профиль.
- frontend/assets: временные фрагменты предоставленных референсов; не оригинальные обложки. Замените файлами <id>.jpg; если изображения нет, используется символ. Перед публичным запуском замените референсную графику собственной.
- bot/main.py: long polling, /start, Web App кнопка. Уведомления о выигрыше не включены.
- tests/test_api.py: проверка баланса, открытия, продажи, запрета повторной продажи, пополнения.

## API
GET /api/catalog — каталог; POST /api/session — случайный идентификатор браузерной сессии; GET /api/state — баланс и история; POST /api/topup — +1000; POST /api/open {"id":0} — списание и приз; POST /api/item {"id":1,"action":"sell"} или claim — смена статуса. Авторизация через X-Telegram-Init-Data либо X-Demo-Session. Состояние сохраняется в demo.sqlite3. Не удаляйте файл, если хотите сохранить историю.

## Тесты
`python -m unittest discover -s tests` из корня в активном окружении. `node --check frontend/app.js` при наличии Node.js.

## Ограничения
Это локальная демоверсия, не production: Flask dev server, нет rate limiting, идемпотентности повторных HTTP запросов, админки и реальных платежей. Не используйте для денег. Telegram и браузерное отображение требуют ручной проверки. Для публичного развёртывания нужны production WSGI, HTTPS, мониторинг, резервные копии и проверка безопасности. Туннель открывает локальный сервис в интернет; закрывайте его после тестов.

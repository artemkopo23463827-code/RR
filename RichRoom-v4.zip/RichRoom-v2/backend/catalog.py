# Редактируйте названия, цены и веса здесь. Все предметы виртуальные.
GROUPS = {'Классика': ['Классика', 'Telegram', 'Крипта', 'VIP-ложа'], 'Любовь': ['Поцелуй', 'Валентинка'], 'Зима': ['Снежинка', 'Новогодний бал'], 'Сладости': ['Леденец'], 'Космос и игры': ['Космос', 'Кибер'], 'Хэллоуин': ['Страшилка'], 'Развлечения': ['Кино и сериалы', 'Даты', 'Дискотека', 'Мемы и приколы']}
ICONS=['🎁', '✈️', '🪙', '🐱', '❤️', '💝', '❄️', '🎄', '🍭', '🚀', '🎮', '🎃', '🎬', '📅', '🎧', '🐶']
CASES=[]
for category,names in GROUPS.items():
 for i,name in enumerate(names):
  k=len(CASES); price=[50,75,110,180][i]+(100 if category=='Премиум' else 0)
  CASES.append(dict(id=k,name=name,category=category,price=price,icon=ICONS[k],badge=['Новый','','Топ',''][i],prizes=[dict(art_id=k,name=name+' • '+r,icon=ICONS[k] if j!=1 else '✨',rarity=r,weight=w,value=price*v//100) for j,(r,w,v) in enumerate([('Обычный',55,30),('Редкий',30,60),('Эпический',12,90),('Легендарный',3,100)])]))

# Идентификаторы коллекций Telegram; изображения загружаются с Fragment.
GIFT_SETS = [
 ('plushpepe','swisswatch','cookieheart','preciouspeach'), ('telegram','durovscap','signetring','crystalball'), ('lootbag','signetring','swisswatch','preciouspeach'), ('swisswatch','durovscap','signetring','plushpepe'), ('kissedfrog','cookieheart','lovepotion','heartlocket'), ('cookieheart','heartlocket','lovepotion','kissedfrog'), ('snowglobe','snowmittens','winterwreath','jinglebells'), ('jinglebells','winterwreath','snowglobe','santahat'), ('lollipop','cookieheart','jellybunny','berrybox'), ('astralshard','crystalball','ionichairdryer','moonpendant'), ('toybear','ionichairdryer','durovscap','plushpepe'), ('skullflower','witchhat','spicedwine','crystalball'), ('jesterhat','swisswatch','toybear','durovscap'), ('deskcalendar','cookieheart','jinglebells','heartlocket'), ('discoparty','jesterhat','partyhat','signetring'), ('plushpepe','jellybunny','kissedfrog','toybear')]
for case, gifts in zip(CASES,GIFT_SETS):
 for prize, slug in zip(case['prizes'],gifts):
  prize['gift_slug']=slug
  prize['image']='/static/assets/gift-'+slug+'.webp'
  prize['name']=slug.title()

CASES.append(dict(id=16,name="Telegram Premium",category="Классика",price=149,icon="⭐",badge="",prizes=[dict(name="Telegram Premium (демо)",gift_slug="premium",image="/static/assets/gift-premium.webp",art_id=16,icon="⭐",rarity="Обычный",weight=100,value=45)]))

# Редактируйте названия, цены и веса здесь. Все предметы виртуальные.
GROUPS = {'Классика': ['Классика', 'Telegram', 'Крипта', 'VIP-ложа'], 'Любовь': ['Поцелуй', 'Валентинка'], 'Зима': ['Снежинка', 'Новогодний бал'], 'Сладости': ['Леденец'], 'Космос и игры': ['Космос', 'Кибер'], 'Хэллоуин': ['Страшилка'], 'Развлечения': ['Кино и сериалы', 'Даты', 'Дискотека', 'Мемы и приколы']}
ICONS=['🎁', '✈️', '🪙', '🐱', '❤️', '💝', '❄️', '🎄', '🍭', '🚀', '🎮', '🎃', '🎬', '📅', '🎧', '🐶']
CASES=[]
for category,names in GROUPS.items():
 for i,name in enumerate(names):
  k=len(CASES); price=[50,75,110,180][i]+(100 if category=='Премиум' else 0)
  CASES.append(dict(id=k,name=name,category=category,price=price,icon=ICONS[k],badge=['Новый','','Топ',''][i],prizes=[dict(art_id=k,name=name+' • '+r,icon=ICONS[k] if j!=1 else '✨',rarity=r,weight=w,value=price*v//100) for j,(r,w,v) in enumerate([('Обычный',55,30),('Редкий',30,60),('Эпический',12,90),('Легендарный',3,100)])]))

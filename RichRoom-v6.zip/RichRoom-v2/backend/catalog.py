# Редактируйте названия, цены и веса здесь. Все предметы виртуальные.
GROUPS = {'Классика': ['Классика', 'Telegram', 'Крипта', 'VIP-ложа'], 'Любовь': ['Поцелуй', 'Валентинка'], 'Зима': ['Снежинка', 'Новогодний бал'], 'Сладости': ['Леденец'], 'Космос и игры': ['Космос', 'Кибер'], 'Хэллоуин': ['Страшилка'], 'Развлечения': ['Кино и сериалы', 'Даты', 'Дискотека', 'Мемы и приколы']}
ICONS=['🎁', '✈️', '🪙', '🐱', '❤️', '💝', '❄️', '🎄', '🍭', '🚀', '🎮', '🎃', '🎬', '📅', '🎧', '🐶']
CASES=[]
for category,names in GROUPS.items():
 for i,name in enumerate(names):
  k=len(CASES); price=[50,75,110,180][i]+(100 if category=='Премиум' else 0)
  CASES.append(dict(id=k,name=name,category=category,price=price,icon=ICONS[k],badge=['Новый','','Топ',''][i],prizes=[dict(art_id=k,name=name+' • '+r,icon=ICONS[k] if j!=1 else '✨',rarity=r,weight=w,value=price*v//100) for j,(r,w,v) in enumerate([('Обычный',55,30),('Редкий',30,60),('Эпический',12,90),('Легендарный',3,100)])]))

# Идентификаторы коллекций Telegram; изображения загружаются с Fragment.
GIFT_SETS = [
 ('plushpepe','swisswatch','cookieheart','preciouspeach'), ('telegram','durovscap','signetring','crystalball'), ('lootbag','signetring','swisswatch','preciouspeach'), ('swisswatch','durovscap','signetring','plushpepe'), ('kissedfrog','cookieheart','lovepotion','heartlocket'), ('cookieheart','heartlocket','lovepotion','kissedfrog'), ('snowglobe','snowmittens','winterwreath','jinglebells'), ('jinglebells','winterwreath','snowglobe','santahat'), ('lollipop','cookieheart','jellybunny','berrybox'), ('astralshard','crystalball','ionichairdryer','moonpendant'), ('toybear','ionichairdryer','durovscap','plushpepe'), ('skullflower','witchhat','spicedwine','crystalball'), ('jesterhat','swisswatch','toybear','durovscap'), ('deskcalendar','cookieheart','jinglebells','heartlocket'), ('discoparty','jesterhat','partyhat','signetring'), ('plushpepe','jellybunny','kissedfrog','toybear')]
for case, gifts in zip(CASES,GIFT_SETS):
 for prize, slug in zip(case['prizes'],gifts):
  prize['gift_slug']=slug
  prize['image']='/static/assets/gift-'+slug+'.webp'
  prize['name']=slug.title()

CASES.append(dict(id=16,name="Telegram Premium",category="Классика",price=149,icon="⭐",badge="",prizes=[dict(name="Telegram Premium (демо)",gift_slug="premium",image="/static/assets/gift-premium.webp",art_id=16,icon="⭐",rarity="Обычный",weight=100,value=45)]))

# Clean collection artwork, not marketplace screenshots. Virtual demo values only.
EXTRA = [('toybear','heartlocket'),('swisswatch','astralshard'),('durovscap','heartlocket'),('lootbag','preciouspeach'),('jellybunny','preciouspeach'),('plushpepe','jellybunny'),('santahat','cookieheart'),('snowmittens','cookieheart'),('jellybunny','preciouspeach'),('signetring','swisswatch'),('astralshard','crystalball'),('jesterhat','skullflower'),('crystalball','heartlocket'),('snowglobe','preciouspeach'),('jellybunny','crystalball'),('cookieheart','jesterhat')]
NAMES={'plushpepe':'Plush Pepe','swisswatch':'Swiss Watch','cookieheart':'Cookie Heart','preciouspeach':'Precious Peach','durovscap':"Durov’s Cap",'signetring':'Signet Ring','crystalball':'Crystal Ball','lootbag':'Loot Bag','kissedfrog':'Kissed Frog','lovepotion':'Love Potion','heartlocket':'Heart Locket','snowglobe':'Snow Globe','snowmittens':'Snow Mittens','winterwreath':'Winter Wreath','jinglebells':'Jingle Bells','santahat':'Santa Hat','lollipop':'Lol Pop','jellybunny':'Jelly Bunny','berrybox':'Berry Box','astralshard':'Astral Shard','ionichairdryer':'Ionic Dryer','moonpendant':'Moon Pendant','toybear':'Toy Bear','skullflower':'Skull Flower','witchhat':'Witch Hat','spicedwine':'Spiced Wine','jesterhat':'Jester Hat','deskcalendar':'Desk Calendar','discoparty':'Disco Party','partyhat':'Party Hat'}
for c in CASES:
 if c['id']==16:
  slugs=['premium','plushpepe','heartlocket','swisswatch','durovscap','astralshard']
 else:
  slugs=list(GIFT_SETS[c['id']])+list(EXTRA[c['id']]); slugs=['hangingstar' if x=='telegram' else x for x in slugs]; slugs=list(dict.fromkeys(slugs))
  for x in ['hangingstar','heartlocket','plushpepe','astralshard']:
   if len(slugs)>=6: break
   if x not in slugs: slugs.append(x)
 c['prizes']=[dict(gift_slug=s,name=NAMES.get(s,{'premium':'Telegram Premium (демо)','hangingstar':'Hanging Star'}.get(s,s)),image=('/static/assets/approved-16.webp' if s=='premium' else 'https://fragment.com/file/gifts/'+({'lollipop':'lolpop','ionichairdryer':'ionicdryer'}.get(s,s))+'/thumb.webp'),rarity=r,weight=w,value=c['price']*v//100,icon='★') for s,r,w,v in zip(slugs,['Обычный','Обычный','Редкий','Редкий','Эпический','Легендарный'],[30,25,20,15,8,2],[30,40,60,80,90,100])]
